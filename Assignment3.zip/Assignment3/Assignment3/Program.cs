﻿using System;
namespace Assignment3
{
    class MainClass
    {
        public static void Main(string[] args)
        {
            string month, day, year, another;
            do
            {
                // Ask user to input month, day, and year of their birthday.
                Console.WriteLine("\nPlease enter the month of your birthday: ");
                month = Console.ReadLine();
                Console.WriteLine("\nPlease enter the day of your birthday: ");
                day = Console.ReadLine();
                Console.WriteLine("\nPlease enter the year of your birthday: ");
                year = Console.ReadLine();
                // Assign each month to a case to be executed.
                switch (month)
                {
                    case "January":
                        Console.WriteLine("\nThe month of January means: Janus, the protector of the doorways.\n");
                        break;
                    case "February":
                        Console.WriteLine("\nThe month of February means: Derived from the word Februalia. This translates to English as a time for sacrifice and atonement of our sins.\n");
                        break;
                    case "March":
                        Console.WriteLine("\nThe month of March means: Mars, the god of war.\n");
                        break;
                    case "April":
                        Console.WriteLine("\nThe month of April means: Derived from the word aperire. The English meaning is to open buds.\n");
                        break;
                    case "May":
                        Console.WriteLine("\nThe month of May means: Maia, the goddess of all plant growth.\n");
                        break;
                    case "June":
                        Console.WriteLine("\nThe month of June means: Youth.\n");
                        break;
                    case "July":
                        Console.WriteLine("\nThe month of July means: Julius Caesar.\n");
                        break;
                    case "August":
                        Console.WriteLine("\nThe month of August means: Augustus Caesar.\n");
                        break;
                    case "September":
                        Console.WriteLine("\nThe month of September means: Seven\n");
                        break;
                    case "October":
                        Console.WriteLine("\nThe month of October means: Eight\n");
                        break;
                    case "November":
                        Console.WriteLine("\nThe month of November means: Nine\n");
                        break;
                    case "December":
                        Console.WriteLine("\nThe month of December means: Ten\n");
                        break;
                }
                // Assign each day to be executed.
                switch (day)
                {
                    case "1":
                        Console.WriteLine("The " + day + "st, of " + month + " means: You are a self-starter with very innovative ways of creating opportunity. You've never been afraid to be the first to try something new. Your determination and endurance are powerful and will help you get through times of struggle and reach success.\n");
                        break;
                    case "2":
                        Console.WriteLine("The " + day + "nd, of " + month + " means: If your birthday is the 2nd, you have a great talent for finding solutions. Your intuitive and unbiased nature allow you to see all sides of any situation and advise others toward the most fair and beneficial outcome.\n");
                        break;
                    case "3":
                        Console.WriteLine("The " + day + "rd, of " + month + " means: Expression comes naturally to you. You are very skilled at communicating your thoughts through conversation and creative pursuits, and your upbeat, charismatic presence inspires others to get onboard with your ideas.\n");
                        break;
                    case "4":
                        Console.WriteLine("The " + day + "th, of " + month + " means: With a 4 Birthday number, you bring stability and rationality to any situation. You are the rock and your hard work and perseverance make you a dependable friend, colleague, parent, and partner.\n");
                        break;
                    case "5":
                        Console.WriteLine("The " + day + "th, of " + month + " means: Flexibility is your forte. When life throws you a curveball, you can easily adapt to new circumstances and find excitement in the unexpected change. This ability to turn on a dime gives you the power to jump on brief opportunities others may miss.\n");
                        break;
                    case "6":
                        Console.WriteLine("The " + day + "th, of " + month + " means: If your date of birth is the 6th, then your heart is your gift. You are a natural-born nurturer and have a great talent for helping and healing others. You are the epitome of self-sacrifice and a fierce protector of those you love.\n");
                        break;
                    case "7":
                        Console.WriteLine("The " + day + "th, of " + month + " means: You possess a very refined mind and a deep urge to uncover life's mysteries. Your ability to acquire vast knowledge on both the informational and spiritual planes gives you a greater awareness than most.\n");
                        break;
                    case "8":
                        Console.WriteLine("The " + day + "th, of " + month + " means: With a Birthday number 8, yours is a story of success. Your talent for setting and reaching goals is like no other. You are self-sufficient and capable and hold a great amount of power to achieve your ambitions.\n");
                        break;
                    case "9":
                        Console.WriteLine("The " + day + "th, of " + month + " means: It's your compassion that makes you shine. You're devoted to helping the greater good and have a strong talent for speaking up for others. Your soul is most satisfied when you are giving and being of service.\n");
                        break;
                    case "10":
                        Console.WriteLine("The " + day + "th, of " + month + " means: Your 10 Birthday number blesses you with great leadership skills. Your mind is sharp and allows you to dream up ingenious ideas and organize all the details, then direct others how to carry things out.\n");
                        break;
                    case "11":
                        Console.WriteLine("The " + day + "th, of " + month + " means: You have a keen awareness of what's happening around you. A strong intuition is your gift and will help you understand the unspoken feelings, thoughts, and fears of others. This insight allows you to be a great guide and supporter\n");
                        break;
                    case "12":
                        Console.WriteLine("The " + day + "th, of " + month + " means: With the number 12 as your date of birth, creativity is a driving force in your life. Your imagination is rich and you are able to express your feelings and insights in unique ways that others can benefit from.\n");
                        break;
                    case "13":
                        Console.WriteLine("The " + day + "th, of " + month + " means: Driven by the number 13, you are a conscientious worker with a knack for coming up with creative ideas and turning them into something real. An optimistic but practical outlook keeps you determined and on track as you work steadily toward your goals.\n");
                        break;
                    case "14":
                        Console.WriteLine("The " + day + "th, of " + month + " means: You are open-minded and always up to try something new, yet you are wise enough to stop and think before you jump right into things. This pragmatic approach helps ensure your time, attention, and efforts are directed into meaningful experiences.\n");
                        break;
                    case "15":
                        Console.WriteLine("The " + day + "th, of " + month + " means: If you were born on the 15th day of the month, your love for others is powerful and you are able to spread your gift of support far and wide. Your curious and social nature brings you into contact with a variety of people, all who would benefit from your heartfelt words of wisdom.\n");
                        break;
                    case "16":
                        Console.WriteLine("The " + day + "th, of " + month + " means: Your 16 Birthday number blesses you with an inquisitive mind that allows you to uncover important truths. You have a special ability to read into other people's feelings and motives and share with them your wisdom.\n");
                        break;
                    case "17":
                        Console.WriteLine("The " + day + "th, of " + month + " means: The quality of work you can produce when you're going it alone is almost unbelievable. You are as independent as you are ambitious, capable of performing every step along the way with efficiency, focus, and skill.\n");
                        break;
                    case "18":
                        Console.WriteLine("The " + day + "th, of " + month + " means: You are both open-minded and open-hearted and your ambition is to leave this world better than you found it. You are independent by nature but will feel most fulfilled and successful when you are of service to others.\n");
                        break;
                    case "19":
                        Console.WriteLine("The " + day + "th, of " + month + " means: With your 19 Birthday number, independence and self-sufficiency are necessities to you. You are extremely capable in life and work and aren't afraid to take big risks to achieve the life you desire.\n");
                        break;
                    case "20":
                        Console.WriteLine("The " + day + "th, of " + month + " means: You relate to others on an almost cosmic level. You are dedicated to building cooperative, harmonious relationships of all kinds and can use your sensitive intuition to sense and address the needs of others.\n");
                        break;
                    case "21":
                        Console.WriteLine("The " + day + "st, of " + month + " means: If your birthday is on the 21st, you thrive in active social settings and find great value in connecting with people. Your natural charm paired with your creative styles of thinking and communicating makes you an exciting and inspiring presence to those in your life.\n");
                        break;
                    case "22":
                        Console.WriteLine("The " + day + "nd, of " + month + " means: A 22 Birthday number gives you the power to create great things. You are determined and hardworking and your ability to cooperate with others makes you an effective teammate or leader.\n");
                        break;
                    case "23":
                        Console.WriteLine("The " + day + "rd, of " + month + " means: You have a real zest for life and you're eager to experience anything and everything possible. You approach relationships and situations in an easygoing way and are a source of optimism and inspiration for others.\n");
                        break;
                    case "24":
                        Console.WriteLine("The " + day + "th, of " + month + " means: With your Birthday number 24, you have a heart of gold and are very skilled at maintaining balanced, stable relationships. You are loyal to your loved ones and are able to be the nurturer, protector, and provider all at once.\n");
                        break;
                    case "25":
                        Console.WriteLine("The " + day + "th, of " + month + " means: You have a great ability to take in and process information on both conscious and subconscious levels. Your curiosity is endless and your desire to dive deep into a variety of subjects will bring you an immense awareness of the world.\n");
                        break;
                    case "26":
                        Console.WriteLine("The " + day + "th, of " + month + " means: If you were born on the 26th day of the month, you have a desire to succeed and will feel most accomplished when your work benefits others. Your intuitive awareness of what people want allows you to come up with innovative solutions to meet their needs.\n");
                        break;
                    case "27":
                        Console.WriteLine("The " + day + "th, of " + month + " means: Your mind is wide open and you are tolerant and compassionate toward all ways of life. You are able to take in a vast amount of insights and information and apply this knowledge toward the greater good.\n");
                        break;
                    case "28":
                        Console.WriteLine("The " + day + "th, of " + month + " means: In an effort to accomplish great things, you recognize the value of working with others. You make a capable and compassionate leader who can bring people together and drive the team toward achievement.\n");
                        break;
                    case "29":
                        Console.WriteLine("The " + day + "th, of " + month + " means: With a 29 Birthday number, you have an amazing ability to bring things together. You receive powerful subconscious insights that help you clearly see how everything and everyone is connected.\n");
                        break;
                    case "30":
                        Console.WriteLine("The " + day + "th, of " + month + " means: If the date of your birth is the 30th, you are an original, innovative thinker and an excellent communicator. You have a great talent for using creativity to convey your ideas and your optimistic attitude has an uplifting effect on others.\n");
                        break;
                    case "31":
                        Console.WriteLine("The " + day + "st, of " + month + " means: Your approach to life is an effective mix of both practicality and imagination. Your mind is stirring with creative ideas and you have the organizational skills to manifest them on the physical plane.\n");
                        break;
                }
                // Assign each year to be executed.
                switch (year)
                {
                    case "2000":
                        Console.WriteLine("The year " + year + " means: You were born on the year of the Dragon.\n");
                        break;
                    case "2001":
                        Console.WriteLine("The year " + year + " means: You were born on the year of the Snake.\n");
                        break;
                    case "2002":
                        Console.WriteLine("The year " + year + " means: You were born on the year of the Horse.\n");
                        break;
                    case "2003":
                        Console.WriteLine("The year " + year + " means: You were born on the year of the Goat.\n");
                        break;
                    case "2004":
                        Console.WriteLine("The year " + year + " means: You were born on the year of the Monkey.\n");
                        break;
                    case "2005":
                        Console.WriteLine("The year " + year + " means: You were born on the year of the Rooster.\n");
                        break;
                    case "2006":
                        Console.WriteLine("The year " + year + " means: You were born on the year of the Dog.\n");
                        break;
                    case "2007":
                        Console.WriteLine("The year " + year + " means: You were born on the year of the Pig.\n");
                        break;
                    case "2008":
                        Console.WriteLine("The year " + year + " means: You were born on the year of the Rat.\n");
                        break;
                    case "2009":
                        Console.WriteLine("The year " + year + " means: You were born on the year of the Ox.\n");
                        break;
                    case "2010":
                        Console.WriteLine("The year " + year + " means: You were born on the year of the Tiger.\n");
                        break;
                    case "2011":
                        Console.WriteLine("The year " + year + " means: You were born on the year of the Rabbit.\n");
                        break;
                    case "2012":
                        Console.WriteLine("The year " + year + " means: You were born on the year of the Dragon.\n");
                        break;
                    case "2013":
                        Console.WriteLine("The year " + year + " means: You were born on the year of the Snake.\n");
                        break;
                    case "2014":
                        Console.WriteLine("The year " + year + " means: You were born on the year of the Horse.\n");
                        break;
                    case "2015":
                        Console.WriteLine("The year " + year + " means: You were born on the year of the Goat.\n");
                        break;
                    case "2016":
                        Console.WriteLine("The year " + year + " means: You were born on the year of the Monkey.\n");
                        break;
                    case "2017":
                        Console.WriteLine("The year " + year + " means: You were born on the year of the Rooster.\n");
                        break;
                    case "2018":
                        Console.WriteLine("The year " + year + " means: You were born on the year of the Dog.\n");
                        break;
                    case "2019":
                        Console.WriteLine("The year " + year + " means: You were born on the year of the Pig.\n");
                        break;
                    case "2020":
                        Console.WriteLine("The year " + year + " means: You were born on the year of the Rat.\n");
                        break;
                    case "2021":
                        Console.WriteLine("The year " + year + " means: You were born on the year of the Ox.\n");
                        break;
                }
                // Ask if user wants to try the program another time.
                Console.WriteLine("Would you like to try another one? (Y/N): ");
                another = Console.ReadLine();
                if (another != "Y" && another != "y")
                {
                    // If user does not want to try another time, output the following statement.
                    Console.WriteLine("\nThank you for playing!");
                }
            }
            // If user wants to try again, the process will be repeated.
            while (another != "N" && another != "n");
        }
    }
}